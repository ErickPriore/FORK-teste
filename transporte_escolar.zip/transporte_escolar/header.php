<?php if(!isset($noHeader) || !$noHeader): ?>
<nav>
  <a href="lista_alunos.php">Alunos</a>
  <a href="add-aluno.php">Novo Aluno</a>
  <a href="cad_onibus.php">Cadastro Ônibus</a>
  <a href="logout.php">Sair</a>
</nav>
<?php endif; ?>