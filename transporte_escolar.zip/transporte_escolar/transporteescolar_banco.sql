CREATE DATABASE IF NOT EXISTS transporteescolar;
USE transporteescolar;
/* SQL tables as before... */